% ---------------------------- Check the following 2 papers ------------------------------- %
%                                                                                           %
%   Bikowski, J., J.A. Huisman, J.A. Vrugt, H. Vereecken, and J. van der Kruk (2012),       %
%      Inversion and sensitivity analysis of ground penetrating radar data with waveguide   %
%      dispersion using deterministic and Markov chain Monte Carlo methods, Near Surface    %
%      Geophysics, Special issue "Physics-based integrated characterization", 10(6),        %
%      641-652, doi:10.3997/1873-0604.2012041, 2012.                                        %
%   Vrugt, J.A., C.J.F. ter Braak, H.V. Gupta, and B.A. Robinson (2009), Equifinality of    %
%       formal (DREAM) and informal (GLUE) Bayesian approaches in hydrologic modeling?,     %
%       Stochastic Environmental Research and Risk Assessment, 23(7), 1011-1026, 	        %
%       doi:10.1007/s00477-008-0274-y.                                                      %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% Problem settings defined by user
DREAMPar.T = 1000;                       % Number of generations
DREAMPar.lik = 12;                       % Model output is simulation: Gaussian log-likelihood
% with inference of measurement error

%% Provide information parameter space and initial sampling
Par_info.initial = 'latin';                 % Latin hypercube sampling
Par_info.boundhandling = 'reflect';         % Explicit boundary handling
Par_info.min = [ 1.0 0.10 0.10 0.00 0.10 ]; % If 'latin', min values
Par_info.max = [ 500 2.00 0.99 0.10 0.99 ]; % If 'latin', max values

%% Define name of function (.m file) for posterior exploration
Func_name = 'hymodMATLAB';

%% Which measurement error shall we take? (with DREAMPar.lik = 12, 13 or 16!!)
homoscedastic = 1;

%% We attempt to estimate the Meas_info error (homoscedastic)
if homoscedastic
    % Sigma independent of magnitude of y (Meas_info.Y)
    Meas_info.Sigma = inline('a');
    % Now add "a" to the parameter ranges ("a" will be estimated)
    Par_info.min = [Par_info.min 0.5]; Par_info.max = [Par_info.max 100];
else
    % Sigma linearly dependent on y (Meas_info.Y)
    Meas_info.Sigma = inline('a + b*Y');
    % "a" is slope, and "b" is intercept !! (make sure that Sigma > 0 )
    Par_info.min = [Par_info.min 0 0]; Par_info.max = [Par_info.max 1 1];
end
%% NOTE: ONE CAN SPECIFY ANY TYPE OF HETEROSCEDASTIC ERROR MODEL!

%% How many parameters do we have total?
DREAMPar.d = size(Par_info.min,2);

%% Define the measured streamflow data
load bound.txt; Meas_info.Y = bound(65:795,4);

%% Optional setting
%options.parallel = 'yes';               % Run in parallel
options.modout = 'yes';                 % Return model (function) simulations of samples (yes/no)?

%% Run the MT-DREAM_ZS algorithm
[chain,output,fx,Z] = MTDREAM_ZS(Func_name,DREAMPar,Par_info,Meas_info,options);
