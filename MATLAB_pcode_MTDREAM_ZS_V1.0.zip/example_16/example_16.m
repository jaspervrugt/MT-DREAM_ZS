% The problem is simplified compared to the paper cited below as it considers a problem in
% which the true model represent a model with the same dimension as the inverse parameterization
% and it uses straight rays. Results can be visualized by the function visualize_results.m

% -------------------------- Check the following 4 papers --------------------------------- %
%                                                                                           %
%   Linde, N., and J.A. Vrugt (2013), Spatially distributed soil moisture from traveltime   %
%       observations of crosshole ground penetrating radar using Markov chain Monte Carlo,  %
%       Vadose Zone Journal, 12(1), 1-16                                                    %
%   Laloy, E., N. Linde, and J.A. Vrugt (2012), Mass conservative three-dimensional water   %
%       tracer distribution from Markov chain Monte Carlo inversion of time-lapse           %
%       ground-penetrating radar data, Water Resour. Res., 48, W07510,                      %
%       doi:10.1029/2011WR011238.                                                           %
%   Carbajal, M.R., N. Linde, T. Kalscheuer, and J.A. Vrugt (2014), Two-dimensional         %
%       probabilistic inversion of plane-wave electromagnetic data: Methodology, model      %
%       constraints and joint inversion with electrical resistivity data, Geophysical       %
%       Journal International}, 196(3), 1508-1524, doi: 10.1093/gji/ggt482.                 %
%   Lochbuhler, T., S.J. Breen, R.L. Detwiler, J.A. Vrugt, and N. Linde (2014),             %
%       Probabilistic electrical resistivity tomography for a CO_2 sequestration analog,    %
%       Journal of Applied Geophysics, 107, 80-92, doi:10.1016/j.jappgeo.2014.05.013.       %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% DCT order in x and z dimension?
func.parx = 8; func.parz = 8;

%% Problem settings defined by user
DREAMPar.d = func.parx * func.parz;     % Dimension of the problem
DREAMPar.T = 10000;                     % Number of generations
DREAMPar.thinning = 5;                  % Only store each 5th sample
DREAMPar.lik = 2;                       % Model output is log-likelihood

%% Define name of function (.m file) for posterior exploration
Func_name = 'DCT_GPR';

%% Provide information parameter space and initial sampling
Par_info = GPR_par_ranges ( func );                                 % Define the parameter ranges
Par_info.initial = 'normal';                                        % Multinormal initial sampling distribution
Par_info.mu = Par_info.min + 0.5 * ( Par_info.max - Par_info.min ); % If 'normal', define mean of distribution
Par_info.cov = 0.001 * diag( Par_info.max - Par_info.min );         % If 'normal', define covariance matrix

% Provide information to do initial sampling ('normal') --> The initial
% chain positions are concentrated in the middle of the parameter ranges
% This will speed up convergence -- but cannot be done in practice!

%% Run the MT-DREAM_ZS algorithm
[chain,output,fx,Z] = MTDREAM_ZS(Func_name,DREAMPar,Par_info);
