% ---------------------------- Check the following 4 papers ------------------------------- %
%                                                                                           %
%   Sadegh, M., and J.A. Vrugt (2013), Bridging the gap between GLUE and formal statistical %
%       approaches: approximate Bayesian computation, Hydrology and Earth System Sciences,  %
%       17, 4831�4850.                                                                      %
%   Vrugt, J.A., and M. Sadegh (2013), Toward diagnostic model calibration and evaluation:  %
%       Approximate Bayesian computation, Water Resources Research, 49, 4335�4345,          %
%       doi:10.1002/wrcr.20354.                                                             %
%   Sadegh, M., and J.A. Vrugt (2014), Approximate Bayesian computation using Markov chain  %
%       Monte Carlo simulation: DREAM_(ABC), Water Resources Research,                      %
%       doi:10.1002/2014WR015386.                                                           %
%   Turner, B.M., and P.B. Sederberg (2013), Approximate Bayesian computation with          %
%       differential evolution, Journal of Mathematical Psychology, In Press.               %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% Problem settings defined by user
DREAMPar.d = 1;                         % Dimension of the problem
DREAMPar.T = 10000;                     % Number of generations
DREAMPar.lik = 21;                      % ABC formal likelihood function
DREAMPar.m0 = 20;                       % Make sure that initial archive is large enough

%% Provide information parameter space and initial sampling
Par_info.initial = 'latin';             % Latin hypercube sampling
Par_info.boundhandling = 'reflect';     % Explicit boundary handling
Par_info.min = -10;                     % If 'latin', min values
Par_info.max =  10;                     % If 'latin', max values

%% Define name of function (.m file) for posterior exploration
Func_name = 'ABC_func';

%% Define Meas_info.S
Meas_info.S = 0;

%% Optional settings
options.epsilon = 0.025;               % Epsilon of the noisy ABC implementation
options.rho = inline('X - Y');         % Define the distance function

%% Run the MT-DREAM_ZS algorithm
[chain,output,fx,Z] = MTDREAM_ZS(Func_name,DREAMPar,Par_info,Meas_info,options);
