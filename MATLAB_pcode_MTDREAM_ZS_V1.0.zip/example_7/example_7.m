% -------------------------------- Check the following paper ------------------------------ %
%                                                                                           %
%   Scharnagl, B., J.A. Vrugt, H. Vereecken, and M. Herbst (2011), Bayesian inverse         %
%      modeling of soil water dynamics at the field scale: using prior information on soil  %
%      hydraulic properties, Hydrology and Earth System Sciences, 15, 3043�3059,            %
%      doi:10.5194/hess-15-3043-2011.                                                       %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% Problem settings defined by user
DREAMPar.d = 7;                         % Dimension of the problem
DREAMPar.T = 5000;                      % Number of generations
DREAMPar.lik = 11;                      % Model output is simulation (soil moisture values)

%% Provide information parameter space and initial sampling (use of informative multiplicative prior)
Par_info.initial = 'prior';             % Initial sample from prior distribution
Par_info.prior = { ...
    'normpdf(0.0670,0.0060)',...        % Marginal prior of theta_r
    'normpdf(0.4450,0.0090)',...        % Marginal prior of theta_s
    'normpdf(-2.310,0.0600)',...        % Marginal prior of log10(alpha)
    'normpdf(0.2230,0.0110)',...        % Marginal prior of log10(n)
    'normpdf(-1.160,0.2700)',...        % Marginal prior of log10(Ks)
    'normpdf(0.3900,1.4700)',...        % Marginal prior of L
    'unifpdf(-250,-50)' };              % Marginal prior of h_bot
Par_info.boundhandling = 'reflect';     % Enforce boundaries of parameter space

%% Define feasible parameter space (minimum and maximum values)
% parname		[ thetar thetas	log10(alpha) log10(n) log10(Ks)	  L    h_bot
Par_info.min =	[ 0.0430 0.4090	 -2.5528	 0.1790   -2.2366	-5.49	-250 ];  % For boundary handling
Par_info.max =	[ 0.0910 0.4810	 -2.0706	 0.2670   -0.0800	 6.27	-50  ];  % For boundary handling

%% Define name of function (.m file) for posterior exploration
Func_name = 'HYDRUS';

%% Define measurement data ( observed soil moisture contents )
data_hydrus = Load_data; Meas_info.Y = data_hydrus.water;

%% Optional settings
options.parallel = 'yes';              % Run chains in parallel
options.IO = 'yes';                    % Input-output writing of model files (for parallel setting only!)
options.save = 'yes';                  % Save memory of DREAM during trial

%% Run the MT-DREAM_ZS algorithm
[chain,output,fx,Z] = MTDREAM_ZS(Func_name,DREAMPar,Par_info,Meas_info,options,data_hydrus);