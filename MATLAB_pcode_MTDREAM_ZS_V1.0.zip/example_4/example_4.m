% ---------------------------- Check the following 3 papers ------------------------------- %
%                                                                                           %
%   Vrugt, J.A., C.J.F. ter Braak, M.P. Clark, J.M. Hyman, and B.A. Robinson (2008),        %
%      Treatment of input uncertainty in hydrologic modeling: Doing hydrology backward with %
%      Markov chain Monte Carlo simulation, Water Resources Research, 44, W00B09,           %
%      doi:10.1029/2007WR006720, 2008.                                                      %
%   Vrugt, J.A., C.J.F. ter Braak, H.V. Gupta, and B.A. Robinson (2009), Equifinality of    %
%       formal (DREAM) and informal (GLUE) Bayesian approaches in hydrologic modeling?      %
%       Stochastic Environmental Research and Risk Assessment, 23(7), 1011-1026, 		    %
%       doi:10.1007/s00477-008-0274-y.                                                      %
%   Vrugt, J.A., H.V. Gupta, W. Bouten and S. Sorooshian (2003), A Shuffled Complex         %
%       Evolution Metropolis algorithm for optimization and uncertainty assessment of       %
%       hydrologic model parameters, Water Resour. Res., 39 (8), 1201,                      %
%       doi:10.1029/2002WR001642, 2003.                                                     %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% Problem settings defined by user
DREAMPar.d = 5;                         % Dimension of the problem
DREAMPar.T = 2000;                      % Number of generations
DREAMPar.lik = 11;                      % Model output is simulation: Gaussian likelihood function

%% Provide information parameter space and initial sampling
Par_info.initial = 'latin';                 % Latin hypercube sampling
Par_info.boundhandling = 'reflect';         % Explicit boundary handling
Par_info.min = [1.0 0.10 0.10 0.00 0.10];   % If 'latin', min values
Par_info.max = [500 2.00 0.99 0.10 0.99];   % If 'latin', max values

%% Define name of function (.m file) for posterior exploration
Func_name = 'hymodMATLAB';

%% Define the measured streamflow data
load bound.txt; Meas_info.Y = bound(65:795,4);

% We need to specify the Meas_info error of the data in Meas_info.Sigma
% With DREAMPar.lik = 3, Meas_info.Sigma is integrated out the likelihoon function
% With some other likelihood functions, you have to define Sigma

% We can estimate the measurement error directly if we use temporal differencing
% The function MeasError provides an estimate of error versus flow level
% out = MeasError(Meas_info.Y);
% For the Leaf River watershed this results in a heteroscedastic error
% that is about 10% of the actual measured discharge value, thus
% You can check this by plotting out(:,1) versus out(:,2)
% Meas_info.Sigma = 0.1 * Meas_info.Y; % DREAMPar.lik = 2 or 7

% We can also estimate the measurement error by specifying
% Meas_info.Sigma = inline('a'); --> homoscedastic
% And add to Par_info min and max the ranges of "a"
% One can also do a heteroscedastic error. Please check example 17

%% Optional settings
options.modout = 'yes';                % Return model (function) simulations of samples (yes/no)?
options.parallel = 'yes';              % Run each chain on a different core

%% Run the MT-DREAM_ZS algorithm
[chain,output,fx,Z] = MTDREAM_ZS(Func_name,DREAMPar,Par_info,Meas_info,options);