% ---------------------------- Check the following two papers ----------------------------- %
%                                                                                           %
%   Vrugt, J.A., C.J.F. ter Braak, C.G.H. Diks, D. Higdon, B.A. Robinson, and J.M. Hyman    %
%       (2009), Accelerating Markov chain Monte Carlo simulation by differential evolution  %
%       with self-adaptive randomized subspace sampling, International Journal of Nonlinear %
%       Sciences and Numerical Simulation, 10(3), 271-288.                                  %
%   Ter Braak, C.J.F., and J.A. Vrugt (2008), Differential Evolution Markov Chain with      %
%       snooker updater and fewer chains, Statistics and Computing,                         %
%       10.1007/s11222-008-9104-9.                                                          %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% Problem settings defined by user
DREAMPar.d = 100;                       % Dimension of the problem
DREAMPar.T = 30000;                     % Number of generations
DREAMPar.thinning = 2;                  % Only store each 10th sample
DREAMPar.lik = 2;                       % Model output is log-likelihood

%% Provide information parameter space and initial sampling
Par_info.initial = 'latin';             % Latin hypercube sampling
Par_info.min = -5 * ones(1,DREAMPar.d); % If 'latin', min values
Par_info.max = 15 * ones(1,DREAMPar.d); % If 'latin', max values

%% Define name of function (.m file) for posterior exploration
Func_name = 'normalfunc';

%% Run the MT-DREAM_ZS algorithm
[chain,output,fx,Z] = MTDREAM_ZS(Func_name,DREAMPar,Par_info);