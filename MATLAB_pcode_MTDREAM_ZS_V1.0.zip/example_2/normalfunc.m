function [log_L] = normalfunc(x)
% Multivariate normal distribution with specified covariance matrix

% Store local variables in memory
persistent d mu C invC log_F
 
% Specify the covariance matrix --> do only once
if isempty(invC),
    
    % How many dimensions?
    d = size(x,2); mu = zeros(1,d);
    
    % Construct the d x d covariance matrix
    A = 0.5 * eye( d , d ) + 0.5 * ones( d , d );
    
    % Rescale to variance-covariance matrix of interest
    for i = 1 : d,
        for j = 1 : d,
            C(i,j) = A(i,j) * sqrt(i * j);
        end
    end
    
    % Now compute the inverse of the covariance matrix
    invC = inv(C);

    % Calculate integration constant
    
    log_F = log ( ( ( 2 * pi )^( - d / 2 ) ) * det(C)^( - 1 / 2 ) );
    
    % log_F becomes -Inf for large d --> hence we set log_F to zero
    % Also need to resolve this in importance distribution as well!!
    if ( d > 150 ),
        log_F = 0;
    end;
    
end

if d == 1, % 1d Gaussian
    log_L = log_F - 1/2 * invC * (x.^2)';
else % > 1d Gaussian
    log_L = log_F - 1/2 * sum(x'.*(invC*x'));
end

% Calculate the log density - without integration constant
%log_L = -0.5 * x * invC * x';

% Or MATLAB built-in function (but with proper normalization)
%log_L = log ( mvnpdf ( x , mu , C )' );