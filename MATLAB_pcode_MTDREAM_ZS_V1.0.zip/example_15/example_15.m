% ---------------------------- Check the following 4 papers ------------------------------- %
%                                                                                           %
%   Sadegh, M., and J.A. Vrugt (2014), Approximate Bayesian computation using Markov chain  %
%       Monte Carlo simulation: DREAM_(ABC), Water Resources Research,                      %
%       doi:10.1002/2014WR015386.                                                           %
%   Vrugt, J.A., and M. Sadegh (2013), Toward diagnostic model calibration and evaluation:  %
%       Approximate Bayesian computation, Water Resources Research, 49, 4335�4345,          %
%       doi:10.1002/wrcr.20354.                                                             %
%   Sadegh, M., and J.A. Vrugt (2013), Bridging the gap between GLUE and formal statistical %
%       approaches: approximate Bayesian computation, Hydrology and Earth System Sciences,  %
%       17, 4831�4850.                                                                      %
%   Turner, B.M., and P.B. Sederberg (2013), Approximate Bayesian computation with          %
%       differential evolution, Journal of Mathematical Psychology, In Press.               %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% Problem settings defined by user
DREAMPar.d = 20;                         % Dimension of the problem
DREAMPar.T = 3000;                       % Number of generations
DREAMPar.lik = 21;                       % ABC formal likelihood function

%% Provide information parameter space and initial sampling
Par_info.initial = 'latin';              % Latin hypercube sampling
Par_info.boundhandling = 'fold';         % Explicit boundary handling
Par_info.min = zeros(1,20);              % If 'latin', min values
Par_info.max = 10 * ones(1,20);          % If 'latin', max values

%% Define name of function (.m file) for posterior exploration
Func_name = 'ABC_binormal';

%% Lets create the observed summary metrics - the mean (mu) of ten bivariate normals
Meas_info.S = Par_info.min' + rand(DREAMPar.d,1) .* ( Par_info.max - Par_info.min )';

%% Optional settings
options.rho = inline(' sqrt( 1 / 20 * sum((X - Y).^2)) ');

%% Run the MT-DREAM_ZS algorithm
[chain,output,fx,Z] = MTDREAM_ZS(Func_name,DREAMPar,Par_info,Meas_info,options);
