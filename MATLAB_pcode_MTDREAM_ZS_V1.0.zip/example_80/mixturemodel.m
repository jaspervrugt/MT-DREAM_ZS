function [ log_L ] = mixturemodel(x)
% Multivariate normal distribution with two modes

% This is MATLAB implementation
%L = 1/3 * mvnpdf(x,mu_1,C) + 2/3 * mvnpdf(x,mu_2,C);
% This is faster (20 times)
%L = 1/3 * exp ( - (x+5)*(x+5)' ) + 2/3 * exp ( - (x-5)*(x-5)' );

% Store local variables in memory
persistent k L mu log_F

% Specify the covariance matrix --> do only once
if isempty(k)
    
    % How many dimensions?
    d = size(x,2);
    
    % How many components does mixture distribution have?
    k = 3;

    % Determine the weight of each normal component of target
    log_prior = log ( [1/6 2/6 3/6] );
    
    % The mean of each indiviual component (= mode)
    mu = [ -5*ones(1,d) ; 5*ones(1,d) ; 15*ones(1,d) ];
    
    % Define the covariance matrix (same for all components)
    C = eye(d,d);
    
    % compute the log determinant of covariance
    [L,f] = chol( C  ); diagL = diag( L );
    
    % Calculate part of normalization constant
    logDetSigma = 2 * sum ( log ( diagL ) );
    
    % Calculate total normalization constant
    % log_F = -0.5 * logDetSigma + log_prior - d*log(2*pi)/2;
    %log_F = - sum ( log ( diag(L) ) ) + log_prior - d * log( 2 * pi ) / 2;
    
end

% Now loop over each component of mixture
for j = 1 : k
    
    % Subtract the mean
    %x_inv = bsxfun(@minus, x, mu(j,:)) / L;
    
    % Compute mahal distance
    %mahalaD(:,j) = sum(x_inv.^2, 2);
    
    % Calculate log_likelihood of jth component
    %log_lh(:,j) = -0.5 * mahalaD(:,j) + log_F(j);
    log_lh(:,j) = -.5 * sum ( ( bsxfun(@minus, x, mu(j,:)) / L ).^2 , 2) + log_F(j);

end

% Now determine the overall log-likelihood
maxll = max(log_lh,[],2);

% Minus maxll to avoid numerical underflow
post = exp(bsxfun(@minus, log_lh, maxll));

% Density(i) is \sum_j \alpha_j P(x_i| \theta_j)/ exp(maxll(i))
density = sum(post,2)';

% % Normalize posteriors
% post = bsxfun(@rdivide, post, density);

% Calculate log-L
log_L = log(density) + maxll';