% ---------------------------- Check the following 3 papers ------------------------------- %
%                                                                                           %
%   Nash, J.E. (1960), A unit hydrograph study with particular reference to British         %
%       catchments, Proceedings - Institution of Civil Engineers, 17, 249-282      .        %
%   Nash, J.E., J.V. Sutcliffe (1970), River flow forecasting through conceptual models     %
%       part I - A discussion of principles, Journal of Hydrology, 10(3), 282-290.          %
%   Beven, K.J., and A.M. Binley (1992), The future of distributed models: Model            %
%       calibration and uncertainty prediction. Hydrological Processes, 6, 279�298,         %
%       doi: 10.1002/hyp.3360060305.                                                        %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% Problem settings defined by user
DREAMPar.d = 1;                         % Dimension of the problem
DREAMPar.T = 5000;                      % Number of generations
DREAMPar.lik = 12;                      % Gaussian likelihood with measurement error
DREAMPar.m0 = 20;                       % Define initial size archive

%% Provide information parameter space and initial sampling
Par_info.initial = 'latin';             % Latin hypercube sampling
Par_info.boundhandling = 'reflect';     % Explicit boundary handling
Par_info.min =  1;                      % If 'latin', min values
Par_info.max = 100;                     % If 'latin', max values

%% Define name of function (.m file) for posterior exploration
Func_name = 'Nash_Cascade';

%% Create the data: synthetic time series
Y = Nash_Cascade(2);
%% Now define heteroscedastic measurement error
Meas_info.Sigma = max( 1/5 * Y , 1e-2);
%% Observed data: Model simulation with heteroscedastic measurement error
Meas_info.Y = normrnd(Y,Meas_info.Sigma);

%% Optional settings
options.modout = 'yes';                % Return model (function) simulations of samples (yes/no)?

%% Run the MT-DREAM_ZS algorithm
[chain,output,fx,Z] = MTDREAM_ZS(Func_name,DREAMPar,Par_info,Meas_info,options);
