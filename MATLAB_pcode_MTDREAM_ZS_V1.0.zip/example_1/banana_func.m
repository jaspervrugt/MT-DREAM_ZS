function [log_L] = banana_func(x)

% Hyperbolic shaped posterior probability distribution

% Store local variables in memory
persistent b d invC log_F

% Specify the covariance matrix --> do only once
if isempty(invC)
    
    % How many dimensions?
    d = size(x,2);
   
    % What is the nonlinearity of the target?
    b = 0.1;
    
    % Target covariance
    C = eye(d,d); C(1,1) = 100; invC = inv(C);
  
    % Calculate integration constant
    log_F = log ( ( ( 2 * pi )^( - d / 2 ) ) * det(C)^( - 1 / 2 ) );
    
    % log_F becomes -Inf for large d --> hence we set log_F to zero
    % Also need to resolve this in importance distribution as well!!
    if ( d > 150 )
        log_F = 0;
    end;

end

% Introduce banana shaped nonlinearity between x(1) and x(2)
x(:,2) = x(:,2) + b * x(:,1).^2 - 100 * b;

if d == 1 % 1d Gaussian
    log_L = log_F - 1/2 * invC * (x.^2)';
else % > 1d Gaussian
    log_L = log_F - 1/2 * sum(x'.*(invC*x'));
end