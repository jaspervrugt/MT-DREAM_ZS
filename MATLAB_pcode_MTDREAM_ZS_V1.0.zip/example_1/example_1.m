% ---------------------------- Check the following 2 papers ------------------------------- %
%                                                                                           %
%   Vrugt, J.A., C.J.F. ter Braak, C.G.H. Diks, D. Higdon, B.A. Robinson, and J.M. Hyman    %
%       (2009), Accelerating Markov chain Monte Carlo simulation by differential evolution  %
%       with self-adaptive randomized subspace sampling, International Journal of Nonlinear %
%       Sciences and Numerical Simulation, 10(3), 271-288.                                  %
%   Vrugt, J.A., H.V. Gupta, W. Bouten and S. Sorooshian (2003), A Shuffled Complex         %
%       Evolution Metropolis algorithm for optimization and uncertainty assessment of       %
%       hydrologic model parameters, Water Resour. Res., 39 (8), 1201,                      %
%       doi:10.1029/2002WR001642.                                                           %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% Problem settings defined by user
DREAMPar.d = 2;                         % Dimension of the problem
DREAMPar.T = 20000;                      % Number of generations
DREAMPar.lik = 2;                       % Model output is log-likelihood

%% Provide information parameter space and initial sampling
Par_info.initial = 'normal';            % multinormal initial sampling distribution
Par_info.mu = zeros(1,DREAMPar.d);      % if 'normal', define mean of distribution
Par_info.cov = 10 * eye(DREAMPar.d);    % if 'normal', define covariance matrix

%% Define name of function (.m file) for posterior exploration
Func_name = 'banana_func';
options.print = 'yes';
%% Run the MT-DREAM_ZS algorithm
[chain,output,fx,Z] = MTDREAM_ZS(Func_name,DREAMPar,Par_info,[],options);