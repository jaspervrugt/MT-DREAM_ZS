% ---------------------------- Check the following paper ---------------------------------- %
%                                                                                           %
%   Minasny, B., J.A. Vrugt, and A.B. McBratney (2011), Confronting uncertainty in model-   %
%       based geostatistics using Markov chain Monte Carlo simulation, Geoderma, 163,       %
%       150-162, doi:10.1016/j.geoderma.2011.03.011.                                        %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% Problem settings defined by user
DREAMPar.d = 5;                         % Dimension of the problem
DREAMPar.T = 1000;                      % Number of generations
DREAMPar.lik = 2;                       % Model output is log-likelihood

%% Provide information parameter space and initial sampling
Par_info.initial = 'latin';             % Latin hypercube sampling
Par_info.boundhandling = 'reflect';     % Explicit boundary handling
Par_info.min = [0 0.00 0.00 0.00 0];    % If 'latin', min values
Par_info.max = [100 100 1000 1000 20];  % If 'latin', max values

%% Define name of function (.m file) for posterior exploration
Func_name = 'blpmodel';

%% Run the MT-DREAM_ZS algorithm
[chain,output,fx,Z] = MTDREAM_ZS(Func_name,DREAMPar,Par_info);

%% Postprocess the results to generate some fitting results
ParSet = GenParSet(chain); Postproc_variogram
