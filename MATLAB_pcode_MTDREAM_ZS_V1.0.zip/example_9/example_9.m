% ---------------------------- Check the following 2 papers ------------------------------- %
%                                                                                           %
%   Schoups, G., J.A. Vrugt, F. Fenicia, and N.C. van de Giesen (2010), Corruption of       %
%       accuracy and efficiency of Markov Chain Monte Carlo simulation by inaccurate        %
%       numerical implementation of conceptual hydrologic models, Water Resources           %
%       Research, 46, W10530, doi:10.1029/2009WR008648.                                     %
%   Schoups, G., and J.A. Vrugt (2010), A formal likelihood function for parameter and      %
%       predictive inference of hydrologic models with correlated, heteroscedastic and      %
%       non-Gaussian errors, Water Resources Research, 46, W10531, doi:10.1029/2009WR008933.%
%   Montanari, A., and E. Toth (2007), Calibration of hydrological models in the spectral   %
%       domain: An opportunity for scarcely gauged basins?, Water Resources Research, 43,   %
%       W05434, doi:10.1029/2006WR005184.                                                   %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% Problem settings defined by user
DREAMPar.d = 7;                         % Dimension of the problem
DREAMPar.T = 5000;                      % Number of generations
DREAMPar.lik = 15;                      % Model output is simulation: Spectral (Whittle) likelihood

%% Provide information parameter space and initial sampling
Par_info.initial = 'latin';             % Latin hypercube sampling
Par_info.boundhandling = 'reflect';     % Explicit boundary handling
% parname:      Imax  Smax  Qsmax   alE   alF   Kfast  Kslow
Par_info.min = [ 0.5   10     0    1e-6   -10     0      0    ];    % If 'latin', min values
Par_info.max = [ 10   1000   100   100     10     10    150   ];    % If 'latin', max values

%% Define name of function (.m file) for posterior exploration
Func_name = 'rainfall_runoff';

%% Define the observed streamflow data
daily_data = load('03451500.dly'); Meas_info.Y = daily_data(731:end,6);

%% Optional settings
options.parallel = 'yes';              % Run each chain on different core
options.modout = 'yes';                % Store model simulations

%% Run the MT-DREAM_ZS algorithm
[chain,output,fx,Z] = MTDREAM_ZS(Func_name,DREAMPar,Par_info,Meas_info,options);
