% ---------------------------- Check the following paper ---------------------------------- %
%                                                                                           %
%   Ter Braak, C.J.F., and J.A. Vrugt (2008), Differential Evolution Markov Chain with      %
%       snooker updater and fewer chains, Statistics and Computing,                         %
%       10.1007/s11222-008-9104-9.                                                          %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

% Problem specific parameter settings
DREAMPar.d = 25;                        % Dimension of the problem
DREAMPar.T = 5000;                      % Number of generations
DREAMPar.lik = 2;                       % Model output is log-likelihood

%% Provide information parameter space and initial sampling
Par_info.initial = 'latin';                 % Latin hypercube sampling
Par_info.min = -5 * ones(1,DREAMPar.d);     % Lower bound parameter values
Par_info.max = 15 * ones(1,DREAMPar.d);     % Upper bound parameter values

%% Define name of function (.m file) for posterior exploration
Func_name = 'multi_student';

%% Run the MT-DREAM_ZS algorithm
[chain,output,fx,Z] = MTDREAM_ZS(Func_name,DREAMPar,Par_info);
