% ------------------------------ Check the following paper -------------------------------- %
%                                                                                           %
%   Vrugt, J.A. (2015), Markov chain Monte Carlo simulation using the DREAM software        %
%       package: Theory, concepts, and MATLAB implementation, Environmental Modeling and    %
%       Software, XX, XX, doi:XX/XX.                                                        %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% Problem settings defined by user
DREAMPar.d = 4;         % Dimension of the problem
DREAMPar.T = 5000;      % Number of generations
DREAMPar.lik = 32;      % Informal likelihood function
DREAMPar.GLUE = 10;     % Value (default) of likelihood shape parameter

%% Initial sampling and parameter ranges
Par_info.initial = 'latin';             % Latin hypercube sampling
Par_info.boundhandling = 'reflect';     % Explicit boundary handling: reflection
% Par. names:    alpha beta gamma delta
Par_info.min = [   0     0    0     0    ]; % Lower bound parameters
Par_info.max = [   1     10   1     10   ]; % Upper bound parameters

%% Load calibration data vector
Meas_info.Y = load('abundances.txt');   % Load food web dataset

%% Define name of function (.m file) for posterior exploration
Func_name = 'lotka_volterra';

%% Optional settings
options.parallel = 'yes';   % Run chains in parallel
options.modout = 'yes';     % Store results

%% Run the MT-DREAM_ZS algorithm
[chain,output,fx,Z] = MTDREAM_ZS(Func_name,DREAMPar,Par_info,Meas_info,options);
