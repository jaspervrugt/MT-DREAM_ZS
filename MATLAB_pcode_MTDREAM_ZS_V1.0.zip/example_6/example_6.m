% ---------------------------- Check the following 2 papers ------------------------------- %
%                                                                                           %
%   Schoups, G., J.A. Vrugt, F. Fenicia, and N.C. van de Giesen (2010), Corruption of       %
%       accuracy and efficiency of Markov Chain Monte Carlo simulation by inaccurate        %
%       numerical implementation of conceptual hydrologic models, Water Resources           %
%       Research, 46, W10530, doi:10.1029/2009WR008648.                                     %
%   Schoups, G., and J.A. Vrugt (2010), A formal likelihood function for parameter and      %
%       predictive inference of hydrologic models with correlated, heteroscedastic and      %
%       non-Gaussian errors, Water Resources Research, 46, W10531, doi:10.1029/2009WR008933.%
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% Problem settings defined by user
DREAMPar.d = 11;                         % Dimension of the problem
DREAMPar.T = 3000;                       % Number of generations
DREAMPar.lik = 14; global LV             % Model output is simulation: Generalized likelihood function

%% Provide information parameter space and initial sampling
Par_info.initial = 'latin';              % Latin hypercube sampling

%% index:     1     2     3     4    5     6     7   |  8    9    10  11  12  13   14   15   16  17  18
%% parname: Imax  Smax  Qsmax  alE  alF  Kfast Kslow | std0 std1 beta xi mu1 phi1 phi2 phi3 phi4 K lambda
LV.fpar = [  1    100   10     100   0     2    70     0.1   0    0   1   0   0    0    0    0   0   1  ];
parmin =  [ 0.5   10     0    1e-6  -10    0     0      0    0   -1  0.1  0   0    0    0    0   0  0.1 ];    % If 'latin', min values
parmax =  [ 10   1000   100    100   10   10    150     1    1    1  10  100  1    1    1    1   1   1  ];    % If 'latin', max values
LV.idx_vpar = [ 1 2 3 4 5 6 7 8 9 10 13 ];  % Select the parameters to be sampled
Par_info.boundhandling = 'reflect';         % Explicit boundary handling
Par_info.min = parmin(LV.idx_vpar);         % If 'latin', min values
Par_info.max = parmax(LV.idx_vpar);         % If 'latin', max values

%% Define name of function (.m file) for posterior exploration
Func_name = 'hmodel';

%% Define the measured streamflow data (two-year spin up period)
daily_data = load('03451500.dly'); Meas_info.Y = daily_data(731:end,6);

%% Optional settings
options.parallel = 'yes';              % This example runs in parallel

%% Run the MT-DREAM_ZS algorithm
[chain,output,fx,Z] = MTDREAM_ZS(Func_name,DREAMPar,Par_info,Meas_info,options);