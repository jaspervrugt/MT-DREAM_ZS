%% Problem settings defined by user
DREAMPar.d = 2;                         % Dimension of the problem
DREAMPar.T = 2000;                      % Number of generations
DREAMPar.lik = 1;                       % Model output is likelihood

%% Provide information parameter space and initial sampling
Par_info.initial = 'normal';            % Multinormal initial sampling distribution
Par_info.mu = zeros(1,DREAMPar.d);      % If 'normal', define mean of distribution
Par_info.cov = eye(DREAMPar.d);         % If 'normal', define covariance matrix
Par_info.prior = @(x,a,b) mvnpdf(x,a,b);% Specify a bi-variate prior distribution
Par_info.a = [-2 -2];                   % Mean of prior distribution
Par_info.b = eye(2);                    % Covariance of prior distribution

%% Define name of function (.m file) for posterior exploration
Func_name = 'mixturemodel';

% So the mixture models has two modes at -5 and 5; with the specified prior
% distribution the mode around 5 should disappear. You can compare the
% theoretical distribution with derived from DREAM

%% Run the MT-DREAM_ZS algorithm
[chain,output,fx,Z] = MTDREAM_ZS(Func_name,DREAMPar,Par_info);
