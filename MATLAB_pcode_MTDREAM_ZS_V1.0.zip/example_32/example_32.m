% ---------------------------- Check the following two papers ----------------------------- %
%                                                                                           %
%   Vrugt, J.A., C.J.F. ter Braak, C.G.H. Diks, D. Higdon, B.A. Robinson, and J.M. Hyman    %
%       (2009), Accelerating Markov chain Monte Carlo simulation by differential evolution  %
%       with self-adaptive randomized subspace sampling, International Journal of Nonlinear %
%       Sciences and Numerical Simulation, 10(3), 271-288.                                  %
%   Ter Braak, C.J.F., and J.A. Vrugt (2008), Differential Evolution Markov Chain with      %
%       snooker updater and fewer chains, Statistics and Computing,                         %
%       10.1007/s11222-008-9104-9.                                                          %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% Problem settings defined by user
DREAMPar.d = 25;                        % Dimension of the problem
DREAMPar.thinning = 2;                  % Only store each 10th sample
DREAMPar.lik = 2;                       % Model output is log-likelihood
DREAMPar.N = 5;                         % Five chains
DREAMPar.psnooker = 0;

%% Define name of function (.m file) for posterior exploration
Func_name = 'mixturemodel';

%% Provide information parameter space and initial sampling
Par_info.initial = 'normal';            % Multinormal initial sampling distribution
Par_info.mu = zeros(1,DREAMPar.d);      % If 'normal', define mean of distribution
Par_info.cov = 5*eye(DREAMPar.d);       % If 'normal', define covariance matrix

%% Define method to use {'dream','dream_zs','dream_d','dream_dzs'}
method = 'dream_zs';

switch method
    case {'dream','dream_d'}
        DREAMPar.N = DREAMPar.d;                    % Number of Markov chains
        DREAMPar.T = 10000;                         % Number of generations
    case {'dream_zs','dream_dzs'}
        DREAMPar.N = 5;                             % Number of Markov chains        
        DREAMPar.T = 50000;                         % Number of generations
end

if strcmp(method,'dream_d') || strcmp(method,'dream_dzs')
    Par_info.min = -20*ones(1,DREAMPar.d);          % Min value for discrete sampling
    Par_info.max =  20*ones(1,DREAMPar.d);          % Max value for discrete sampling
    Par_info.steps = 40*ones(1,DREAMPar.d);        % Number of discrete steps
end

%% Run DREAM package
[chain,output,FX,Z,logL] = MTDREAM_ZS(Func_name,DREAMPar,Par_info);