function log_L = mixturemodel(x)
% Multivariate normal distribution with three modes

% This is MATLAB implementation
%L = 1/3 * mvnpdf(x,mu_1,C) + 2/3 * mvnpdf(x,mu_2,C);
% This is faster (20 times)
%L = 1/3 * exp ( - (x+5)*(x+5)' ) + 2/3 * exp ( - (x-5)*(x-5)' );

% Store local variables in memory
persistent k L mu log_F

% Specify the covariance matrix --> do only once
if isempty(k)
    % How many dimensions?
    d = size(x,2);
    % How many Gaussians?
    k = 3;
    % Determine weight of each respective Gaussian
    log_prior = log ( [1/6 2/6 3/6] );
    % Mean of all three modes
    mu = [ -5*ones(1,d) ; 5*ones(1,d) ; 15*ones(1,d) ];
    % Now compute the inverse of the covariance matrix
    C = eye(d,d);
    % compute the log determinant of covariance
    L = chol( C );
    % Calculate part of normalization constant
    logDetSigma = 2 * sum ( log ( diag( L ) ) );
    % Calculate total normalization constant (k values)
    log_F = -0.5 * logDetSigma + log_prior - d*log(2*pi)/2;
end

log_lh = nan(1,k);
% Now loop over each component of mixture
for j = 1:k
    % Subtract the mean
    %x_inv = bsxfun(@minus, x, mu(j,:)) / L;
    % Compute mahal distance
    %mahalaD(:,j) = sum(x_inv.^2, 2);
    % Calculate log_likelihood of jth component
    %log_lh(:,j) = -0.5 * mahalaD(:,j) + log_F(j);
    log_lh(1,j) = -.5 * sum ( ( bsxfun(@minus, x, mu(j,:)) / L ).^2 , 2) + log_F(j);
end

% Now determine the overall log-likelihood
maxll = max (log_lh,[],2);
% Minus maxll to avoid underflow
post = exp(bsxfun(@minus, log_lh, maxll));
% Density(i) is \sum_j \alpha_j P(x_i| \theta_j)/ exp(maxll(i))
density = sum(post,2);
% Normalize posteriors
% post = bsxfun(@rdivide, post, density);
% Calculate log-L
log_L = ( log(density) + maxll )';