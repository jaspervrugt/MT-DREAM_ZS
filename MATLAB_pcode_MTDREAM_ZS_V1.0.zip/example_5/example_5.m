%% Problem settings defined by user
DREAMPar.d = 5;                          % Dimension of the problem
DREAMPar.T = 1000;                       % Number of generations
DREAMPar.lik = 11;                       % Model output is simulation: Gaussian likelihood function

%% Provide information parameter space and initial sampling
Par_info.initial = 'latin';                 % Latin hypercube sampling
Par_info.boundhandling = 'reflect';         % Explicit boundary handling
Par_info.min = [1.0 0.10 0.10 0.00 0.10];   % If 'latin', min values
Par_info.max = [500 2.00 0.99 0.10 0.99];   % If 'latin', max values

%% Define name of function (.m file) for posterior exploration
Func_name = 'hymodFORTRAN';

%% Define the measured streamflow data
load bound.txt; Meas_info.Y = bound(65:795,4);

%% Optional settings
options.parallel = 'yes';               % Run each chain on a different core
options.IO = 'yes';                     % Input-output writing of model files (only for parallel!)
options.modout = 'yes';                 % Return model (function) simulations of samples (yes/no)?

%% Run the MT-DREAM_ZS algorithm
[chain,output,fx,Z] = MTDREAM_ZS(Func_name,DREAMPar,Par_info,Meas_info,options);
